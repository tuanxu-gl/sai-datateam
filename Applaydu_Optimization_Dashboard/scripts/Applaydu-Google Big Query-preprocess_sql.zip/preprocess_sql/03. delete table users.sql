DELETE FROM `gcp-gfb-sai-tracking-gold.applaydu.tbl_users`
WHERE 1=1 AND DATE(server_date) >= '2025-02-01'