delete from `gcp-gfb-sai-tracking-gold.applaydu.tbl_sum_scan_unlock` 
where 1=1 and server_date >= '2025-02-01'