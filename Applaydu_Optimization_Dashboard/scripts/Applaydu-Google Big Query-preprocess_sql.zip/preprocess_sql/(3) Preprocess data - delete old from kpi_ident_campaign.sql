
delete from gcp-gfb-sai-tracking-gold.applaydu.kpi_ident_campaign
where fdate>= '2025-02-01'

