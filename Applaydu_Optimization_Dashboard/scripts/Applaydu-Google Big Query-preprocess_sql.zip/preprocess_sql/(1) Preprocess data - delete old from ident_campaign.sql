delete from `gcp-gfb-sai-tracking-gold.applaydu.ident_campaign`
where fdate > '2025-02-01'
